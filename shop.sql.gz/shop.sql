-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Янв 05 2022 г., 14:53
-- Версия сервера: 5.6.51
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `shop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `peoples_questions`
--

CREATE TABLE `peoples_questions` (
  `id` int(11) NOT NULL,
  `name_people` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_people` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `peoples_questions`
--

INSERT INTO `peoples_questions` (`id`, `name_people`, `mail_people`, `question`) VALUES
(1, 'Влад', 'bk@bk.ru', 'Первый вопрос'),
(2, 'Влад', 'bk@bk.ru', 'Второй вопрос'),
(3, 'Леха', 'fdssv@fgfd', 'Третий вопрос'),
(4, 'Леха', 'bk@bk.ru', 'Текст'),
(5, 'Леха', 'bk@bk.ru', 'Еще текст)');

-- --------------------------------------------------------

--
-- Структура таблицы `products_accessories`
--

CREATE TABLE `products_accessories` (
  `id` int(11) NOT NULL,
  `name_product` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products_accessories`
--

INSERT INTO `products_accessories` (`id`, `name_product`, `way_image1`, `way_image2`, `way_image3`, `description`, `price`, `count`) VALUES
(1, 'Boosted Belt Kit', '../img_product_accessories/product1/1.png', '../img_product_accessories/product1/2.png', '../img_product_accessories/product1/1.png', 'Original Boosted Belt Kits\r\n\r\nV1: Original Boosted Board\r\n\r\nV2: V2, Mini, Plus, and Stealth', 15, 18),
(2, 'Bearing Service Kit', '../img_product_accessories/product2/1.png', '../img_product_accessories/product2/2.png', '../img_product_accessories/product2/3.png', 'Keep your wheels turning!', 50, 21),
(3, 'Shred Lights for Boo', '../img_product_accessories/product3/1.png', '../img_product_accessories/product3/2.png', '../img_product_accessories/product3/3.png', 'Need lights?  Add the all new Shred Light 300 to your order.  Lights with all necessary hardware for front and rear lights. \r\n\r\nThe front lights all ship with front standard mounts, please specify if your rear lights are for a plus/stealth/V2 or Mini X / S.', 35, 8),
(4, 'Boosted Pulley / Bel', '../img_product_accessories/product4/1.png', '../img_product_accessories/product4/2.png', '../img_product_accessories/product4/1.png', 'Tired of changing belts? Try our secret sauce. Drastically increases belt life and removes unnecessary belt slip by replacing your stock plastic pulleys. \r\n\r\n*Images are slightly different than the final product, we are working on getting images but didn,t want to delay the new product. Kit includes 2 pulleys, two belts and 2 bearings.', 75, 0),
(5, 'Boosted Skid Plates', '../img_product_accessories/product5/1.png', '../img_product_accessories/product5/2.png', '../img_product_accessories/product5/1.png', 'OEM Boosted Skid Plates.  Replace your ruddy skid plates and give your board a new look.', 20, 2),
(6, 'Loaded Caguama 85-s ', '../img_product_accessories/product6/1.png', '../img_product_accessories/product6/2.png', '../img_product_accessories/product6/3.png', 'Sold Out\r\n\r\nUPGRADE YOUR BOOSTED BOARD TO CAGUAMA WHEELS!  \r\n\r\nSHIPS IN PAIRS (without pulleys or bearings):\r\n\r\nIf you want a full set please add 2 to your cart ($68 total) Please note if you need drive pulleys or bearings please check back, they are coming soon. \r\n\r\nBIG AND BEAUTIFUL.\r\n\r\nVoluptuous urethane (proportionate in all the right places) for high roll speed, grip, comfort, and momentum for commuting, carving, long-distance pushing, pumping, and electric longboards. ', 85, 3),
(7, 'Boosted 105-s', '../img_product_accessories/product7/1.png', '../img_product_accessories/product7/2.png', '../img_product_accessories/product7/3.png', 'Sold Out\r\n\r\nThese complete wheel sets are extremely rare.  We have very limited supply of the 105-s.  These are the biggest baddest wheels that Boosted has ever produced.\r\n\r\nWhat is Included?\r\n\r\n2 Drive Wheels\r\n\r\n2 Metal Drive Pulleys\r\n\r\n2 Front Wheels\r\n\r\n*Original packaging. No wheel bearings included - Does include the metal pulley and pulley bearing. \r\n\r\n Two per customer Limit!', 75, 3),
(8, 'Boosted Beams', '../img_product_accessories/product8/1.png', '../img_product_accessories/product8/2.png', '../img_product_accessories/product8/3.png', 'Sold Out\r\n\r\nThese Boosted Beams are EXTREMELY Limited. They plug into current Boosted Boards and use your battery to light-up the road. Made by Boosted for Boosted.  \r\n\r\n*Limit to 1 per customer, if you order 2 your order will be canceled. \r\n\r\n*Boosted Beams require firmware 2.7.0 or newer, or they will not work.', 55, 4);

-- --------------------------------------------------------

--
-- Структура таблицы `products_el_scooters`
--

CREATE TABLE `products_el_scooters` (
  `id` int(11) NOT NULL,
  `name_product` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products_el_scooters`
--

INSERT INTO `products_el_scooters` (`id`, `name_product`, `way_image1`, `way_image2`, `way_image3`, `description`, `price`, `count`) VALUES
(1, 'Boosted Rev Electric ', '../img_product_el_scooters/scooter1/1.png', '../img_product_el_scooters/scooter1/2.png', '../img_product_el_scooters/scooter1/3.png', 'The Worlds most desirable scooter is back. Packed full of power this dual motor scooter attacks hills with speed and comfort. The Boosted Rev is by far the smoothest, safest scooter on the planet. Get to where you are going with style and ease. \r\nRefurb Condition - Like new out of the box. Motors, display, and wheels are all new. The deck might have light scuffs. Manuals not included. 60 day warranty applies.  *Packaging will be original but will notebe double boxed.\r\n\r\nUsed Condition - The scooter will have signs of use including but not limited to: Packaging (will not ship double boxed), wheels, motors, brakes, tires, deck, display.  Used scooters have been thoroughly inspected, cleaned, and been QCed by our Rev team. Used scooters are sold as is, our warranty does not apply.', 550, 21);

-- --------------------------------------------------------

--
-- Структура таблицы `products_el_skateboards`
--

CREATE TABLE `products_el_skateboards` (
  `id` int(11) NOT NULL,
  `name_product` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `way_image3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products_el_skateboards`
--

INSERT INTO `products_el_skateboards` (`id`, `name_product`, `way_image1`, `way_image2`, `way_image3`, `description`, `price`, `count`) VALUES
(1, 'Boosted Mini X', '../img_product_el_skate/skate1/1.png', '../img_product_el_skate/skate1/2.png', '../img_product_el_skate/skate1/3.png', 'Where Power Meets Agility.  The Mini X is the favorite board for old school shredders and those looking for the most nimble board available today.\r\nNew Condition - New in box, all original packing materials. \r\n\r\nRefurb Condition - Like new out of the box. Motors, guards, and wheels are all new. The deck might have light scuffs. Manuals not included. 60 day warranty applies. \r\n\r\nUsed Condition - Battery, Motors, and belts operate perfectly.  The board will have signs of use including but not limited to: Packaging, motor guards, deck, and covers.  Used boards are sold as is,  our warranty does not apply.', 250, 48),
(2, 'Boosted Plus V3', '../img_product_el_skate/skate2/1.png', '../img_product_el_skate/skate2/2.png', '../img_product_el_skate/skate2/3.png', 'In stock: Carved from the Original Boosted Board, The plus offers everything that riders love in the sleek original form.', 200, 27),
(3, 'Boosted Mini S', '../img_product_el_skate/skate3/1.png', '../img_product_el_skate/skate3/2.png', '../img_product_el_skate/skate3/3.png', 'Boosted Mini is the stash-and-go Boosted experience you’ve been waiting for. At only 29.5 inches long, it fits perfectly under desks, in overhead storage on busses and trains, and is built for riders who are always on the move. Our new custom-designed composite deck provides a wide, stable standing platform and features a Deep Dish concave shape for superior control. The kicktail design allows for quick pivoting in close quarters and lets you “float” over road imperfections. Best of all, Boosted Mini delivers the same powerful acceleration and smooth, secure braking you expect from Boosted with ride modes and acceleration patterns designed to suit the board’s compact profile. Boosted Mini is where power meets agility. Get moving!', 270, 7),
(4, 'Boosted Stealth ', '../img_product_el_skate/skate4/1.png', '../img_product_el_skate/skate4/2.png', '../img_product_el_skate/skate4/3.png', 'The pinnacle of performance.  The Boosted Stealth is the fastest, cleanest and most powerful skateboard ever built.\r\nNew Condition -  New in box, all original packing materials. \r\n\r\nRefurb Condition - Like new out of the box. Motors, guards, and wheels are all new. The deck might have light scuffs. Manuals not included. 60 day warranty applies. \r\n\r\nUsed Condition - Battery, Motors, and belts operate perfectly.  The board will have signs of use including but not limited to: Packaging, motor guards, deck, and covers.  Used boards are sold as is,  our warranty does not apply.', 350, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name_user` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthday` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `men_or_women` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name_user`, `surname`, `login`, `birthday`, `email`, `phone_number`, `men_or_women`, `address`, `password`) VALUES
(1, 'Vlad', 'Abinin', 'Admin', '1999-11-18', 'mail@mail.ru', '89998887766', 'Мужской', 'г.Брянск, ул.Красавчика, д.100', '11111'),
(2, 'Петр', 'Васечкин', 'top', '2022-01-09', 'bk@bk.ru', '89008004589', 'Мужской', 'г.Вологда', '12345'),
(3, 'Михаил', 'Иванюк', 'Mixa', '2007-02-04', 'mixail@yandex.ru', '89443886712', 'Мужской', 'г.Смоленск', '00000'),
(4, '', '', 'user_new', '', 'bk@bk.ru', '', '', '', '55555');

-- --------------------------------------------------------

--
-- Структура таблицы `users_products_bascet_all`
--

CREATE TABLE `users_products_bascet_all` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name_product` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users_products_bascet_all`
--

INSERT INTO `users_products_bascet_all` (`id`, `product_id`, `name_product`, `user_id`, `price`, `count`, `image`) VALUES
(12, 1, 'Boosted Rev Electric', 3, 550, 1, '../img_product_el_scooters/scooter1/1.png'),
(13, 3, 'Boosted Mini S', 3, 270, 22, '../img_product_el_skate/skate3/1.png'),
(14, 3, 'Shred Lights for Boo', 2, 35, 2, '../img_product_accessories/product3/1.png'),
(15, 5, 'Boosted Skid Plates', 2, 20, 4, '../img_product_accessories/product5/1.png'),
(16, 1, 'Boosted Mini X', 2, 250, 1, '../img_product_el_skate/skate1/1.png');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `peoples_questions`
--
ALTER TABLE `peoples_questions`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products_accessories`
--
ALTER TABLE `products_accessories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products_el_scooters`
--
ALTER TABLE `products_el_scooters`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `products_el_skateboards`
--
ALTER TABLE `products_el_skateboards`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users_products_bascet_all`
--
ALTER TABLE `users_products_bascet_all`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `peoples_questions`
--
ALTER TABLE `peoples_questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `products_accessories`
--
ALTER TABLE `products_accessories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `products_el_scooters`
--
ALTER TABLE `products_el_scooters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `products_el_skateboards`
--
ALTER TABLE `products_el_skateboards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `users_products_bascet_all`
--
ALTER TABLE `users_products_bascet_all`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
